i=1
n=int(input("Enter the number:"))
fact=1
while(i<=n):
   fact=fact*i
   i=i+1
print(fact)