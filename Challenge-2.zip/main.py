year=int(input ("Enter the year:"))
if(year%4==0):
  print(year,"Is leap year")
else:
  print(year,("Non leap year"))
